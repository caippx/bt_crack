<?php
/**
 * Created by PhpStorm.
 * ser: he
 * Date: 2018/8/25
 * Time: 19:14
 */

/*
{
  u'status': True,
  u'msg': u'weixin://wxpay/bizpayurl?pr=IoQHYvW',
  u'oid': u'100869574',
  u'data': {
    u'status': 0,
    u'wxoid': 170418,
    u'uid': 4132,
    u'addtime': 1535197362,
    u'oid': 100869574,
    u'pid': 100000011,
    u'ptype': 1,
    u'attach': u'153519736290432',
    u'out_trade_no': u'153519736286719',
    u'msg': u'\u5b9d\u5854\u9762\u677f',
    u'cash_fee': 3680
  }
}
 */

echo json_encode([
    'status' => True,
    'msg' => '',
    'data' => []
]);